<h2> Gestion des avions </h2>

<?php
$leAvion=null;
if((isset($_GET['action']))&&(isset($_GET['idavion'])))
{
	$action = $_GET['action'];
	$idavion = $_GET['idavion'];
	switch ($action){
		case "sup": deleteAvion ($idavion); 
		break;
		case"edit":$leAvion = selectWhereAvion($idavion);
		break;
	}
}
require_once("vue/vue_insert_avion.php");
if (isset($_POST['Valider'])) {
	//insertion de l'avion dans la table avion
	insertAvion($_POST);
	echo "<br> Insertion de l'avion réussie.";
}
if(isset($_POST['Modifier']))
{
	updateAvion ($_POST);
	//recharger la page
	header(("Location: index.php?page=3"));
}
$lesAvions = selectAllAvions();
require_once("vue/vue_select_avion.php");
if (isset($_POST['Modifier'])) {
	updateAvion($_POST); // recharger la page
	header(("location: index.php?page=3"));
}
?>