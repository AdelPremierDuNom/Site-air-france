<h2> Bienvenue à Air France </h2>
<br>
<p id="p">L’histoire d’Air France est indissociable de celle de l’aviation civile et de ses progrès tant techniques qu’opérationnels. Des premiers vols des années 1910 au Concorde, d’immenses prouesses ont été réalisées par plusieurs centaines d’hommes et de femmes épris de lointains et d’innovations. A mesure de l’augmentation des capacités de ses avions, Air France a toujours privilégié la sécurité et le confort de ses clients ainsi que l’excellence des services à bord. Grâce à ses atouts, la compagnie fait aujourd’hui partie d’Air France-KLM, l’un des groupes leader dans le transport aérien dans le monde. </p>
<br>
<img src="images/Airfrance.png" height="400" width="700">
<br>
<a href="https://www.airfrance.fr"> Visiter le site de la Air France </a>
<br>
<br>