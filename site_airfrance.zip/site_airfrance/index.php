<?php
require_once("modele/modele.php");
?>

<!DOCTYPE html>
<html>

<head>
	<title> Site Airfrance </title>
	<link rel="stylesheet" type="text/css" href="style.css" />
</head>

<body>
	<center>
		<h1> Gestion des Vols Air France </h1>
		<a href="index.php?page=1">
			<img src="images/logo.png" height="100" width="100"> </a>
		<a href="index.php?page=2">
			<img src="images/pilote.jpg" height="100" width="100"> </a>
		<a href="index.php?page=3">
			<img src="images/avion.jpg" height="100" width="100"> </a>
		<a href="index.php?page=4">
			<img src="images/vol.jpg" height="100" width="100"> </a>

		<?php
		if (isset($_GET['page'])) {
			$page = $_GET['page'];
		} else {
			$page = 1;
		}
		switch ($page) {
			case 1:
				require_once("controleur/home.php");
				break;
			case 2:
				require_once("controleur/gestion_pilote.php");
				break;
			case 3:
				require_once("controleur/gestion_avion.php");
				break;
			case 4:
				require_once("controleur/gestion_vol.php");
				break;
		}
		?>
		<br>
		<footer>
			<h2>Coordonnées</h2>
			<pre>08 92 70 26 54           49 AV de l'Opéra, 75002 Paris, France           mail.informations.generales@airfrance.fr            <a id="n" href="https://www.instagram.com/airfrance/"> Instagram </a> </pre>
		</footer>
	</center>
</body>

</html>