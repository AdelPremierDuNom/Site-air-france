<h3> Ajout d'un pilote </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom </td>
			<td> <input type="text" name="nom" value="<?php if($lePilote!=NULL)echo $lePilote['nom']?>"></td>
		</tr>
		<tr>
			<td> Prénom </td>
			<td> <input type="text" name="prenom" value="<?php if($lePilote!=NULL)echo $lePilote['prenom']?>"></td>
		</tr>
		<tr>
			<td> Email </td>
			<td> <input type="text" name="email" value="<?php if($lePilote!=NULL)echo $lePilote['email']?>"></td>
		</tr>
		<tr>
			<td> Mot de Passe </td>
			<td> <input type="text" name="mdp" value="<?php if($lePilote!=NULL)echo $lePilote['mdp']?>"></td>
		</tr>
		<tr>
			<td> Bip </td>
			<td> <input type="text" name="bip" value="<?php if($lePilote!=NULL)echo $lePilote['bip']?>"></td>
		</tr>
		<tr>
			<td> Statut </td>
			<td> <input type="text" name="statut" value="<?php if($lePilote!=NULL)echo $lePilote['statut']?>"></td>
		</tr>
		<tr>
			<td> <input type="reset" name="Annuler" value="Annuler"> </td>
			<td> <input type="submit"  
			<?php if($lePilote!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
		</tr>
	</table>
	<?php
	if($lePilote !=null){
		echo "<input type='hidden' name='idpilote' value='".$lePilote ['idpilote']."'>";
	}
	?>
</form>