<h3> Ajout d'un vol </h3>
<form method="post">
    <table>
        <tr>
            <td> Désignation </td>
            <td> <input type="text" name="designation" value="<?php if($leVol!=NULL)echo $leVol['designation']?>"> </td>
        </tr>
        <tr>
            <td> Date du vol </td>
            <td> <input type="text" name="datevol" value="<?php if($leVol!=NULL)echo $leVol['datevol']?>"> </td>
        </tr>
        <tr>
            <td> Heure du vol </td>
            <td> <input type="text" name="heurevol" value="<?php if($leVol!=NULL)echo $leVol['heurevol']?>"> </td>
        </tr>
        <tr>
            <td> Pilote </td>
            <td> <input type="text" name="idpilote1" value="<?php if($leVol!=NULL)echo $leVol['idpilote1']?>"> </td>
        </tr>
        <tr>
            <td> Co-pilote </td>
            <td> <input type="text" name="idpilote2" value="<?php if($leVol!=NULL)echo $leVol['idpilote2']?>"> </td>
        </tr>
        <tr>
            <td> Avion </td>
            <td> <input type="text" name="idavion" value="<?php if($leVol!=NULL)echo $leVol['idavion']?>"> </td>
        </tr>
        <tr>
            <td> <input type="reset" name="Annuler" value="Annuler"> </td>
            <td> <input type="submit" <?php if($leVol!=null){
			echo 'name = "Modifier" value ="Modifier"';
			}
			else{
				echo 'name="Valider" value="Valider"';
			}?>> </td>
        </tr>
    </table>
    <?php
	if($leVol !=null){
		echo "<input type='hidden' name='idvol' value='".$leVol ['idvol']."'>";
	}
	?>
</form>