<h3> Liste des Avions </h3>

<table border="1">
	<tr>
		<td> ID Avion </td>
		<td> Désignation </td>
		<td> Constructeur </td>
		<td> Nombre de Places </td>
		<td> Opérations </td>
	</tr>
	<?php
	foreach ($lesAvions as $unAvion) {
		echo "<tr>";
		echo "<td>" . $unAvion['idavion'] . "</td>";
		echo "<td>" . $unAvion['designation'] . "</td>";
		echo "<td>" . $unAvion['constructeur'] . "</td>";
		echo "<td>" . $unAvion['nbplaces'] . "</td>";
		echo "<td>";
		echo "<a href='index.php?page=3&action=sup&idavion=".$unAvion['idavion']."'><img src='images/sup.png' height='50' witdh='50'> </a>";
		echo "<a href='index.php?page=3&action=edit&idavion=".$unAvion['idavion']."'><img src='images/edit.png' height='50' witdh='50'> </a>";
		echo "</td>";
		echo "</tr>";
	}
	?>
</table>