<h3> Liste des Pilotes </h3>

<table border="1">
	<tr>
		<td> ID Pilote </td>
		<td> Nom </td>
		<td> Prénom </td>
		<td> Email </td>
		<td> Mot de Passe </td>
		<td> Bip </td>
		<td> Statut </td>
	</tr>
	<?php
	foreach ($lesPilotes as $unPilote) {
		echo "<tr>";
		echo "<td>" . $unPilote['idpilote'] . "</td>";
		echo "<td>" . $unPilote['nom'] . "</td>";
		echo "<td>" . $unPilote['prenom'] . "</td>";
		echo "<td>" . $unPilote['email'] . "</td>";
		echo "<td>" . $unPilote['mdp'] . "</td>";
		echo "<td>" . $unPilote['bip'] . "</td>";
		echo "<td>" . $unPilote['statut'] . "</td>";
		echo"<td>";
			echo "<a href='index.php?page=2&action=sup&idpilote=".$unPilote['idpilote']."'><img src='images/sup.png' height='50' width='50'></a>";
			echo "<a href='index.php?page=2&action=edit&idpilote=".$unPilote['idpilote']."'><img src='images/edit.png' height='50' width='50'></a>";
			echo"</td>";
		echo "</tr>";
	}
	?>
</table>